package com.example.inspiration_awards;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private LocationManager locationManager;
    private Location currentLocation;
    private Criteria criteria;
    private static String MyPreference = "Pref";
    SharedPreferences preferences;
    private CheckBox checkBox;

    //String userName;
    public String userName,fnames,lnames,depts,locs,imgBytess,poss,storys;
    public Boolean admins;
    int ptsAwards;
    private static int MY_LOCATION_REQUEST_CODE = 329;
    private ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        criteria = new Criteria();
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        //criteria.setPowerRequirement(Criteria.POWER_HIGH);
        criteria.setAccuracy(Criteria.ACCURACY_MEDIUM);
        //criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        //
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    MY_LOCATION_REQUEST_CODE);
        } else {
            //setLocation();
        }

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        checkBox = findViewById(R.id.checkBox);

        TextView tview = (TextView) this.findViewById(R.id.textView3);
        //shared preff
        preferences = getSharedPreferences(MyPreference, Context.MODE_PRIVATE);
        String val1= preferences.getString("Username", "");
        String val2= preferences.getString("Password", "");

        ((EditText) findViewById(R.id.EditText)).setText(val1);
        ((EditText) findViewById(R.id.EditText2)).setText(val2);



        tview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),CreateActivity.class);
                //String place = getPlace(currentLocation);
                //i.putExtra("location",place);
                //i.putExtra("location",currentLocation);
                startActivity(i);
            }
        });




    }



    public void onRequestPermissionsResult(int requestCode, @NonNull
            String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_LOCATION_REQUEST_CODE) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) &&
                    grantResults[0] == PERMISSION_GRANTED) {
                setLocation();
                return;
            }
        }
        Log.d(TAG, "onRequestPermissionsResult: Permission not granted ");
    }
    public void populateData(String uname,String fname,String lname,String dept,String loc,String imgBytes,String pos,int ptsAward, Boolean admin,String story)
    {
        userName=uname;
        fnames=fname;
        lnames=lname;
        depts=dept;
        locs=loc;
        imgBytess=imgBytes;
        poss=pos;
        ptsAwards=ptsAward;
        admins=admin;
        storys=story;
    }
    @SuppressLint("MissingPermission")
    private void setLocation() {

        String bestProvider = locationManager.getBestProvider(criteria, true);

        currentLocation = locationManager.getLastKnownLocation(bestProvider);
        if (currentLocation != null) {
            Log.d(TAG, "setLocation: currentLocation" + currentLocation.getLatitude() + ", " + currentLocation.getLongitude());
        } else {
            Log.d(TAG, "setLocation: Location not found ");
        }
    }

    private String getPlace(Location loc) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> addresses;
        try {
            addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            Log.d("Loc", city+state);
            return city + ", " + state;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
    public void onClick(View v) {
        String sId = "A20424216";
        String uName = ((EditText) findViewById(R.id.EditText)).getText().toString();
        String pswd = ((EditText) findViewById(R.id.EditText2)).getText().toString();
        progressBar.setVisibility(View.GONE);

        if(checkBox.isChecked()==true)
        {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("Username",uName);
            editor.putString("Password",pswd);
            editor.commit();
        }


        if (((Button) findViewById(R.id.button)).isClickable()) {
            progressBar.setVisibility(View.VISIBLE);

        } else {
            progressBar.setVisibility(View.GONE);
        }

        new LoginAPIAyncTask(this).execute(sId, uName, pswd);


        Log.d(TAG, "login: " + uName);
        Log.d(TAG, "login: " + pswd);
    }

    public void sendResults(String res)
    {

            progressBar.setVisibility(View.INVISIBLE);
            try{
                Intent i=new Intent(getApplicationContext(),ProfileCreated.class);
                JSONObject js = new JSONObject(res);
                i.putExtra("nameuser",js.getString("username"));
                i.putExtra("firstName",js.getString("firstName"));
                i.putExtra("lastName",js.getString("lastName"));
                i.putExtra("department",js.getString("department"));
                i.putExtra("position",js.getString("position"));
                i.putExtra("story",js.getString("story"));
                i.putExtra("pointsToaward",js.getString("pointsToAward"));
                i.putExtra("admin",js.getString("admin"));
                i.putExtra("location",js.getString("location"));
                i.putExtra("image",js.getString("imageBytes"));
                if(js.getString("rewards")!="null" || js.getString("rewards")!="[]")
                {

                    i.putExtra("rewards",js.getString("rewards"));
                    Log.d("Amanchu1", "sendResults: here"+js.getString("rewards"));
                }
                i.putExtra("password",js.getString("password"));

                startActivity(i);

            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }



//    public void sendResultPass(){
//
//
//        progressBar.setVisibility(View.INVISIBLE);
//
//        Log.d(TAG, "sendResultPass: Right LOGIN CHECK");
//
//        i.putExtra("nameuser",userName);
//        i.putExtra("firstName",fnames);
//        i.putExtra("lastName",lnames);
//        i.putExtra("department",depts);
//        i.putExtra("position",poss);
//        i.putExtra("story",storys);
//
//
//        i.putExtra("location",locs);
//        Log.d(TAG, "sendResultPass:  LOGIN CHECK loc" + locs);
//          startActivity(i);
//
//    }


}
