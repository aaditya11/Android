package com.example.inspiration_awards;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import static java.net.HttpURLConnection.HTTP_OK;


import android.os.AsyncTask;

public class Award_Asynch extends AsyncTask<String,Void,String> {
    private static final String baseUrl =
            "http://inspirationrewardsapi-env.6mmagpm2pv.us-east-2.elasticbeanstalk.com";
    private static final String Create ="/profiles";
    @SuppressLint("StaticFieldLeak")
    private AwardActivity awardactivty;

    public Award_Asynch (AwardActivity awardactivty) {
        this.awardactivty = awardactivty;
    }
    private static final String TAG = "Award_Asynch";
    @Override
    protected void onPostExecute(String connectionResult) {


        if (connectionResult.contains("error")) {// If there is "error" in the results...

            Toast.makeText(awardactivty,"Error While Adding",Toast.LENGTH_SHORT).show();
            Log.d("Aman111", "failed ");
        }
        else {
            Log.d("Aman111", "SUCCESS");
            awardactivty.done();

        }

    }


    @Override
    protected String doInBackground(String... strings) {

        String us1=strings[0];
        String pss1=strings[1];
        String name=strings[2];
        String us2= strings[3];
        String comments= strings[4];
        String pnts=strings[5];
        int pnts1=Integer.parseInt(pnts);
        SimpleDateFormat date= new SimpleDateFormat("MM/dd/yyyy");
        String date1=date.format(new Date());



        try {
            JSONObject main = new JSONObject();
            JSONObject target = new JSONObject();
            target.put("studentId","A20424216");
            target.put("username", us2);
            target.put("name", name);
            target.put("date", date1);
            target.put("notes", comments);
            target.put("value",pnts1);

            main.put("target",target);

            JSONObject source = new JSONObject();
            source.put("studentId","A20424216");
            source.put("username", us1);
            source.put("password", pss1);

            main.put("source", source);
            Log.d(TAG,"JSON Object-----------"+main.toString());
            return doAPICall(main);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }
    private  String doAPICall(JSONObject jsonObject) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;

        try {

            String urlString = baseUrl + "/rewards";  // Build the full URL

            Uri uri = Uri.parse(urlString);    // Convert String url to URI
            URL url = new URL(uri.toString()); // Convert URI to URL

            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");  // POST - others might use PUT, DELETE, GET

            // Set the Content-Type and Accept properties to use JSON data
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            // Write the JSON (as String) to the open connection
            OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
            out.write(jsonObject.toString());
            out.close();

            int responseCode = connection.getResponseCode();

            StringBuilder result = new StringBuilder();

            // If successful (HTTP_OK)
            if (responseCode == HTTP_OK) {

                // Read the results - use connection's getInputStream
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while (null != (line = reader.readLine())) {
                    result.append(line).append("\n");
                }

                // Return the results (to onPostExecute)

//                createUser.set_data(ln,fn,un,loc1,p2a,dept,pos1,stry);

                Log.d("lapi100", ""+result);
                return result.toString();


            } else {
                // Not HTTP_OK - some error occurred - use connection's getErrorStream
                Log.d("h2", "idhar ");
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
                String line;
                while (null != (line = reader.readLine())) {
                    result.append(line).append("\n");
                }

                // Return the results (to onPostExecute)
                Log.d("hll", result.toString());
                return result.toString();

            }

        } catch (Exception e) {
            // Some exception occurred! Log it.
            Log.d(TAG, "doAuth: " + e.getClass().getName() + ": " + e.getMessage());

        } finally {
            // Close everything!
            if (connection != null) {
                connection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG, "doInBackground: Error closing stream: " + e.getMessage());
                }
            }
        }
        return "Some error has occurred";
    }
}





