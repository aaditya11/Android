package com.example.inspiration_awards;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.List;
import javax.xml.transform.Templates;

public class hist_adapt extends RecyclerView.Adapter<hist_adapt.ViewHolder>{

        private ProfileCreated profileCreated;
        private List<hist_val> rewardvariablesList;
        private static final String TAG = "StockAdapter";

        public hist_adapt(ProfileCreated profileCreated, List<hist_val> rewardvariablesList) {
            this.profileCreated = profileCreated;
            this.rewardvariablesList = rewardvariablesList;
        }



        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.profile_view, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            hist_val st = rewardvariablesList.get(i);
            viewHolder.date.setText(String.valueOf(st.getDate()));
            viewHolder.name.setText(String.valueOf(st.getName()));
            viewHolder.points.setText(String.valueOf(st.getPoints()));
            viewHolder.comments.setText(String.valueOf(st.getComments()));
        }

        @Override
        public int getItemCount() {
            return rewardvariablesList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder{
            private TextView date;
            private TextView name;
            private TextView points;
            private TextView comments;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                date = itemView.findViewById(R.id.name_leaderboard);
                name = itemView.findViewById(R.id.textView);
                points = itemView.findViewById(R.id.points_leaderboard);
                comments = itemView.findViewById(R.id.position_leaderboard);
            }
        }
    }


