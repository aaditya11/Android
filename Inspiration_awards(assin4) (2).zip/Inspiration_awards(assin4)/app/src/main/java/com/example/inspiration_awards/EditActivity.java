package com.example.inspiration_awards;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.location.LocationManager;
import android.net.Uri;
import android.nfc.Tag;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Locale;

import static com.example.inspiration_awards.CreateActivity.makeCustomToast;

public class EditActivity extends AppCompatActivity {
    EditText estory, editpass, editfname, editlname, editdept, editpos;
    String location, imageString;
    AlertDialog.Builder alert;
    private File currentImageFile;
    int points;
    private ImageView trial;
    CheckBox editbox;
    TextView edituser;
    private String path;
    private int REQUEST_IMAGE_GALLERY = 1;
    private AlertDialog dialog;
    private int REQUEST_IMAGE_CAPTURE = 2;
    private static final int PICK_FROM_GALLERY = 1;
    private static final int PICK_FROM_CAMERA =100;
    ImageView editimgview, editimageplus;
    private static final String TAG = "EditActivity";
    String user,firstName,lastName,department,position,story,pass,admin1;
    CheckBox admincheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Edit Profile");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setLogo(R.drawable.arrow_with_logo);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_edit);

        admincheck=(CheckBox)findViewById(R.id.checkBox3) ;
        edituser = (TextView) findViewById(R.id.euname);
        editpass = (EditText) findViewById(R.id.epass);
        editfname = (EditText) findViewById(R.id.efname);
        editlname = (EditText) findViewById(R.id.elname);
        editdept = (EditText) findViewById(R.id.edept);
        editpos = (EditText) findViewById(R.id.epos);
        estory = (EditText) findViewById(R.id.story);

        editbox = (CheckBox) findViewById(R.id.checkBox3);
        editimgview = (ImageView) findViewById(R.id.eimageView);
        editimageplus = (ImageView) findViewById(R.id.imageView3);

        alert = new AlertDialog.Builder(EditActivity.this);

        estory.setFilters(new InputFilter[]{new InputFilter.LengthFilter(360)});

        String uname = getIntent().getStringExtra("nameuser");
        String pass = getIntent().getStringExtra("password");
        String fname = getIntent().getStringExtra("firstName");
        String lname = getIntent().getStringExtra("lastName");
        location = getIntent().getStringExtra("location");
        points = getIntent().getIntExtra("points", 1000);
        String position = getIntent().getStringExtra("position");
        String department = getIntent().getStringExtra("department");
        String story = getIntent().getStringExtra("story");
        imageString = getIntent().getStringExtra("image");
        Log.d("nunnu", "onCreate: "+imageString);
        if(imageString!=null){
            byte[] imageBytes = Base64.decode(imageString,Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            editimageplus.setImageBitmap(bitmap);

        }

        Boolean admin = getIntent().getBooleanExtra("admin",false);

        if (admin.equals("false")) {
            editbox.setChecked(false);
        } else {
            editbox.setChecked(true);
        }
        Log.d(TAG,"password------"+pass);
        edituser.setText(uname);
        editpass.setText(pass);
        editfname.setText(fname);
        editlname.setText(lname);
        editdept.setText(department);
        editpos.setText(position);
        estory.setText(story);








//


//        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
//        StrictMode.setVmPolicy(builder.build());

        editimageplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert.setTitle("Profile Picture");
                alert.setIcon(R.drawable.logo);
                alert.setMessage("Take picture from:").
                        setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                doCamera();
                            }
                        }).setNegativeButton("Gallery", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       doGallery();
                    }
                }).setNeutralButton("Cancel", null);
                AlertDialog alert2 = alert.create();
                alert2.show();

            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case PICK_FROM_GALLERY:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, PICK_FROM_GALLERY);
                } else {
                    //do something like displaying a message that he didn`t allow the app to access gallery and you wont be able to let him select from gallery
                }
                break;
            case PICK_FROM_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(cameraIntent, PICK_FROM_CAMERA);
                }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.updatesave, menu);
        return true;
    }

    public void toast() {
        Toast.makeText(this, "Profile Updated Successfully", Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

//        image = "";
//
//        imageString = "null";

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//        LocationServices locationServices = new LocationServices(EditActivity.this, locationManager);
//        String place = locationServices.getPlace();



        if (id == R.id.updatesave) {

             user = ((TextView) findViewById(R.id.euname)).getText().toString();
            pass = ((EditText) findViewById(R.id.epass)).getText().toString();
             firstName = ((EditText) findViewById(R.id.efname)).getText().toString();
             lastName = ((EditText) findViewById(R.id.elname)).getText().toString();
             department = ((EditText) findViewById(R.id.edept)).getText().toString();
             position = ((EditText) findViewById(R.id.epos)).getText().toString();
             story = ((EditText) findViewById(R.id.story)).getText().toString();

            if (admincheck.isChecked()) {
                admin1 = "true";
            } else {
                admin1 = "false";
            }
            Boolean admincheck = ((CheckBox) findViewById(R.id.checkBox3)).isChecked();
            Log.d(TAG, "onOptionsItemSelected: clicked see or not");
            Log.d("nunssnu", "onOptionsItemSelected: "+imageString);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            final EditActivity ca=this;
            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {
                    Log.d(TAG,"saved!!!!");

                    new EditActivityAsync(ca).execute(
              "A20424216",user,pass,firstName,lastName,"1000",department,position,story,admin1,imageString);
                }
            });

            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();

                }
            });
            builder.setTitle("Save Changes ?");
            builder.setIcon(R.drawable.logo);
            dialog = builder.create();
            dialog.show();
//            new EditActivityAsync(this).execute(
//                "A20424216",user,pass,firstName,lastName,"1000",department,position,story,admin1,imageString);
            Log.d(TAG, "onOptionsItemSelected: On click update save");


        }
            return super.onOptionsItemSelected(item);
        }


    public void sendResults(String s) {
        Intent i = new Intent(getApplicationContext(), ProfileCreated.class);
        i.putExtra("nameuser",user);
        i.putExtra("password",pass);
        i.putExtra("firstName",firstName);
        i.putExtra("lastName",lastName);
        i.putExtra("department",department);
        i.putExtra("position",position);
        i.putExtra("story",story);
        i.putExtra("location",location);
        i.putExtra("image",imageString);
        i.putExtra("pointsToaward","1000");
        startActivity(i);

    }



    public void doCamera() {
        currentImageFile = new File(getExternalCacheDir(), "appimage_" + System.currentTimeMillis() + ".jpg");
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(currentImageFile));
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    public void doGallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_IMAGE_GALLERY);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
            try {
                processGallery(data);
                doConvert();
            } catch (Exception e) {
                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            try {
                processCamera(data);
                doConvert();
            } catch (Exception e) {

                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }
    }

    private void processCamera(Intent data) {
        //Uri selectedImage = Uri.fromFile(currentImageFile);
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");

        trial.setImageBitmap(thumbnail);
        Bitmap bm = ((BitmapDrawable) editimgview.getDrawable()).getBitmap();
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", bm.getByteCount()),
                Toast.LENGTH_LONG);

        currentImageFile.delete();
    }


    private void processGallery(Intent data) {
        Uri galleryImageUri = data.getData();
        if (galleryImageUri == null)
            return;

        InputStream imageStream = null;
        try {
            imageStream = getContentResolver().openInputStream(galleryImageUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final Bitmap Image = BitmapFactory.decodeStream(imageStream);
        final Bitmap selectedImage1 = getResizedBitmap(Image, 100);
        Log.d("yoyoyo", "processGallery: "+selectedImage1);
        editimageplus.setImageBitmap(selectedImage1);
        Log.d("xoxoxo", "processGallery: "+selectedImage1);
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", selectedImage1.getByteCount()),
                Toast.LENGTH_LONG);

    }
    public void doConvert() {
        if (editimageplus.getDrawable() == null)
            return;

//        int jpgQuality = ((SeekBar) findViewById(R.id.seekBar)).getProgress();


        Bitmap origBitmap = ((BitmapDrawable) editimageplus.getDrawable()).getBitmap();

        ByteArrayOutputStream bitmapAsByteArrayStream = new ByteArrayOutputStream();
        origBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bitmapAsByteArrayStream);
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", bitmapAsByteArrayStream.size()),
                Toast.LENGTH_LONG);

        String imgString = Base64.encodeToString(bitmapAsByteArrayStream.toByteArray(), Base64.DEFAULT);
        Log.d("conv", "doConvert: Image in Base64 size: " + imgString.length());
        imageString=imgString;

    }
    public static void makeCustomToast(Context context, String message, int time) {
        Toast toast = Toast.makeText(context, "Image Size: " + message, time);
        View toastView = toast.getView();
        toastView.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
        TextView tv = toast.getView().findViewById(android.R.id.message);
        tv.setPadding(100, 50, 100, 50);
        tv.setTextColor(Color.WHITE);
        toast.show();
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }


}
