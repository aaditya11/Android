package com.example.inspiration_awards;


import android.Manifest;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Locale;

import static android.widget.Toast.LENGTH_SHORT;


public class CreateActivity extends AppCompatActivity {
private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String department;
    private String position;
    private String story;
    private String admin;
    private String image1;
    private String imageString;
    private Boolean admincheck;
    private String path;
    private static final String TAG = "CreateActivity";
//    private int REQUEST_IMAGE_GALLERY = 1;
//    private int REQUEST_IMAGE_CAPTURE = 2;
//    private File currentImageFile;
    ImageView addimage1;
    private AlertDialog dialog;
    private File currentImageFile;
    String location;
    private ImageView trial;
    private ImageView per;
    private EditText etext7;
    private TextView charCountText;
    private int REQUEST_IMAGE_GALLERY = 1;
    private int REQUEST_IMAGE_CAPTURE = 2;
    private static final int PICK_FROM_GALLERY = 1;
    private static final int PICK_FROM_CAMERA =100;
    public static int MAX_CHARS = 360;
    public String loc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Create Profile");
        loc = getIntent().getStringExtra("place");
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setLogo(R.drawable.arrow_with_logo);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_create);

        image1 = "";

        etext7 = findViewById(R.id.etext7);
        etext7.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_CHARS)});
        charCountText = findViewById(R.id.textcount);
        addTextListener();


//        per = findViewById(R.id.imageView);
//
//        location = getIntent().getExtras().getString("location");
//
//        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
//        StrictMode.setVmPolicy(builder.build());

        addimage1 = (ImageView) findViewById(R.id.imageView3);
        trial = (ImageView) findViewById(R.id.imageView);
        Log.d(TAG, "onCreate: Stop1");
        addimage1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(ActivityCompat.checkSelfPermission(CreateActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(CreateActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA}, PICK_FROM_CAMERA);}

                    if (ActivityCompat.checkSelfPermission(CreateActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(CreateActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_FROM_GALLERY);
                    }

                    Builder();

            }
        });

    }

    public void Builder(){
        Log.d(TAG, "onCreate: Stop2");
        AlertDialog.Builder builder = new AlertDialog.Builder(
                CreateActivity.this);
        builder.setIcon(R.drawable.logo);
        builder.setTitle("Profile Picture");
        builder.setMessage("Take picture from:");
        builder.setNegativeButton("GALLERY",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {

                        Toast.makeText(getApplicationContext(),"GALLERY is clicked",Toast.LENGTH_LONG).show();
                        doGallery();
                    }
                });

        Log.d(TAG, "onCreate: Stop3");
        builder.setPositiveButton("CAMERA",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        doCamera();
                        Toast.makeText(getApplicationContext(),"CAMERA is clicked",Toast.LENGTH_LONG).show();
                    }
                });
        builder.setNeutralButton("CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        Toast.makeText(getApplicationContext(),"Cancel is clicked",Toast.LENGTH_LONG).show();
                    }
                });

        builder.show();
    }


    private void addTextListener() {
        etext7.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // Nothing to do here
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
                // Nothing to do here
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                int len = s.toString().length();
                String countText = "(" + len + " of " + MAX_CHARS + ")";
                charCountText.setText(countText);
            }
        });
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.saveimg, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id  = item.getItemId();
        username = ((EditText)findViewById(R.id.etext)).getText().toString();
        password = ((EditText)findViewById(R.id.etext2)).getText().toString();
        firstName = ((EditText)findViewById(R.id.etext3)).getText().toString();
        lastName= ((EditText)findViewById(R.id.etext4)).getText().toString();
        department = ((EditText)findViewById(R.id.etext5)).getText().toString();
        position = ((EditText)findViewById(R.id.etext6)).getText().toString();
        story = ((EditText)findViewById(R.id.etext7)).getText().toString();
        admin = "false";
        admincheck = ((CheckBox)findViewById(R.id.checkBox2)).isChecked();


        //encode image to base64 string
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //Bitmap bitmap = ((BitmapDrawable)per.getDrawable()).getBitmap();
        //bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        //byte[] imageBytes = baos.toByteArray();
        //String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);
//        imageString = path;

        if(admincheck){
            admin = "true";
        }else{
            admin="false";
        }



        if(id == R.id.save){
            Log.d("Saving data......", "onOptionsItemSelected: Saved" + username + " " + lastName);

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            final CreateActivity ca=this;
            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {
                                Log.d(TAG,"saved!!!!");
                    Log.d("uii1", "onClick: "+image1);
                    new CreateActivityAsync(ca).execute("A20424216",username, password, firstName, lastName, "1000",department,story,position,admin, location,image1);
                }
            });

            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();

                }
            });
            builder.setTitle("Save Changes ?");
            builder.setIcon(R.drawable.logo);
            dialog = builder.create();
            dialog.show();


        }
        return super.onOptionsItemSelected(item);
    }
    public void sendResults(String s) {
        Intent i = new Intent(getApplicationContext(),ProfileCreated.class);
        i.putExtra("nameuser",username);
        i.putExtra("password",password);
        i.putExtra("firstName",firstName);
        i.putExtra("lastName",lastName);
        i.putExtra("department",department);
        i.putExtra("position",position);
        i.putExtra("story",story);
        i.putExtra("image",image1);
        i.putExtra("location",location);
        i.putExtra("pointsToaward","1000");
        startActivity(i);

    }


//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults)
//    {
//        switch (requestCode) {
//            case PICK_FROM_GALLERY:
//                // If request is cancelled, the result arrays are empty.
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                    startActivityForResult(galleryIntent, PICK_FROM_GALLERY);
//                } else {
//                    //do something like displaying a message that he didn`t allow the app to access gallery and you wont be able to let him select from gallery
//                }
//                break;
//            case PICK_FROM_CAMERA:
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    Intent cameraIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                    startActivityForResult(cameraIntent, PICK_FROM_CAMERA);
//                }
//
//        }
//    }


    public void doCamera() {
//        //currentImageFile = new File(getExternalCacheDir(), "appimage_" + System.currentTimeMillis() + ".jpg");
//        Intent takePictureIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
//        //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(currentImageFile));
//        Log.d(TAG,"skjdsjdkjskjdksjkfjskjfkjfdkjsfkjksjf");
//        startActivityForResult(takePictureIntent, PICK_FROM_CAMERA);
        currentImageFile = new File(getExternalCacheDir(), "appimage_" + System.currentTimeMillis() + ".jpg");
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(currentImageFile));
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    public void doGallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_IMAGE_GALLERY);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

//        if (requestCode == PICK_FROM_GALLERY && resultCode == RESULT_OK) {
//            try {
//                processGallery(data);
//                doConvert();
//            } catch (Exception e) {
//                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
//                e.printStackTrace();
//            }
//        } else if (requestCode == PICK_FROM_CAMERA && resultCode == RESULT_OK) {
//            try {
//                Log.d(TAG,"camera data----------");
//                processCamera();
//                doConvert();
//            } catch (Exception e) {
//                Log.d(TAG,"jdhfjhdjhgfjhghdjghdhf");
//                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
//                e.printStackTrace();
//            }
//        }
//    }
        if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
            try {
                processGallery(data);
                doConvert();
            } catch (Exception e) {
                Log.d(TAG, "onActivityResult: ioooo");
                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        } else if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            try {
                processCamera();
                doConvert();
            } catch (Exception e) {
                Toast.makeText(this, "onActivityResult: " + e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }

    }

    private void processCamera() {
        Uri selectedImage = Uri.fromFile(currentImageFile);
        addimage1.setImageURI(selectedImage);
        Bitmap bm = ((BitmapDrawable) addimage1.getDrawable()).getBitmap();
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", bm.getByteCount()), Toast.LENGTH_LONG);

        currentImageFile.delete();
    }


    private void processGallery(Intent data) {
        Uri galleryImageUri = data.getData();
        if (galleryImageUri == null)
            return;

        InputStream imageStream = null;
        try {
            imageStream = getContentResolver().openInputStream(galleryImageUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        final Bitmap Image = BitmapFactory.decodeStream(imageStream);
            final Bitmap selectedImage1 = getResizedBitmap(Image, 100);
            Log.d("yoyoyo", "processGallery: "+selectedImage1);
            addimage1.setImageBitmap(selectedImage1);
        Log.d("xoxoxo", "processGallery: "+selectedImage1);
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", selectedImage1.getByteCount()),
                Toast.LENGTH_LONG);

    }
    public void doConvert() {
        if (addimage1.getDrawable() == null)
            return;



        Bitmap origBitmap = ((BitmapDrawable) addimage1.getDrawable()).getBitmap();

        ByteArrayOutputStream bitmapAsByteArrayStream = new ByteArrayOutputStream();
        origBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bitmapAsByteArrayStream);
        makeCustomToast(this,
                String.format(Locale.getDefault(), "%,d", bitmapAsByteArrayStream.size()),
                Toast.LENGTH_LONG);

        String imgString = Base64.encodeToString(bitmapAsByteArrayStream.toByteArray(), Base64.DEFAULT);
        Log.d("conv", "doConvert: Image in Base64 size: " + imgString.length());
        image1=imgString;
        Log.d("Uii", "doConvert: "+image1);

    }
    public static void makeCustomToast(Context context, String message, int time) {
        Toast toast = Toast.makeText(context, "Image Size: " + message, time);
        View toastView = toast.getView();
        toastView.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
        TextView tv = toast.getView().findViewById(android.R.id.message);
        tv.setPadding(100, 50, 100, 50);
        tv.setTextColor(Color.WHITE);
        toast.show();
    }
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 0) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        Log.d("imhere", "getResizedBitmap: ");
        return Bitmap.createScaledBitmap(image, width, height, true);
    }



}
