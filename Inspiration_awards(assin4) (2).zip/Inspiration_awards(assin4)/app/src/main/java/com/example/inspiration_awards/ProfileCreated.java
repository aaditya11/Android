package com.example.inspiration_awards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ProfileCreated extends AppCompatActivity {

    private static final String TAG = "ProfileCreated";
    private static String firstName = "";
    private static String username = "";
    private static String password = "";
    private static String lastName = "";
    private static String dept = "";
    private static String pos = "";
    private static String story = "";
    private static String location = "";
    String image;
    private static String points = "";
    ImageView img1;
    RecyclerView recyclerView;
    private hist_adapt madapter;
    private final static List<hist_val> rewardlist = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        CreateActivity createActivity = new CreateActivity();
        setTitle("Your Profile");
        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setLogo(R.drawable.arrow_with_logo);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.icon);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_profile_created);
        Bundle ext = getIntent().getExtras();

        recyclerView = findViewById(R.id.rc_2);
        madapter = new hist_adapt(this, rewardlist);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(madapter);

        if (ext != null) {
            username = ext.getString("nameuser");
            firstName = ext.getString("firstName");
            lastName = ext.getString("lastName");
            dept = ext.getString("department");
            pos = ext.getString("position");
            story = ext.getString("story");
            image = ext.getString("image");
            Log.d("toodak", "onCreate: "+image);
            location = ext.getString("location");
            points = ext.getString("pointsToaward");
            password = ext.getString("password");
           String reward_his=ext.getString("rewards");
           int sum=0;
            Log.d("helloji", "onCreate: "+reward_his);
           if(reward_his!=null);{
           try {
               JSONArray reward = new JSONArray(reward_his);
               JSONArray ne = new JSONArray();
               if(reward.length()>0)
               {
                   for(int k = 0; k < reward.length(); k++) {
                       JSONObject obj = reward.getJSONObject(k);
                       obj.put("name",obj.getString("name"));
                       obj.put("date", obj.getString("date"));
                       obj.put("value",obj.getString("value"));
                       obj.put("comments",obj.getString("notes"));
                       sum = sum + Integer.parseInt(obj.getString("value"));
                       ne.put(obj);
                   }
                   set_adapt(ne);
               }
           }
           catch (Exception e){
               Log.d(TAG, "onCreate: "+e);
           }

        }}
        Log.d(TAG, "onCreate: image" + points);
        ((TextView) findViewById(R.id.nameuser)).setText(lastName);
        ((TextView) findViewById(R.id.nameuser)).append(", " + firstName);
        ((TextView) findViewById(R.id.nameuser)).append("(" + username + ")");
        ((TextView) findViewById(R.id.textView10)).setText(dept);
        ((TextView) findViewById(R.id.pos)).setText(pos);
        ((TextView) findViewById(R.id.storyy)).setText(story);
        ((TextView) findViewById(R.id.location)).setText(location);
        ((TextView) findViewById(R.id.ptss)).setText(points);
        ((TextView) findViewById(R.id.points)).setText("0");
        Log.d(TAG, "onCreate: location" + location);
        Log.d("nunnu2", "onCreate: image" + image);
        img1=findViewById(R.id.img);


        if(image!=null)
        {
            Log.d("nunn3", "onCreate: here!!!!!");
//            byte[] imageBytes = Base64.decode(image,  Base64.DEFAULT);
//            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
//            img1.setImageBitmap(bitmap);
            byte [] imageBytes = Base64.decode(image, Base64.DEFAULT);
            Log.d("nunn3", "doConvert: Image byte array length: " + image.length());
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            Log.d("nunn3", "" + bitmap);

            img1.setImageBitmap(bitmap);
        }

        recyclerView = findViewById(R.id.rc_2);
        madapter = new hist_adapt(this, rewardlist);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(madapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.edit) {
            Intent i = new Intent(getApplicationContext(), EditActivity.class);
            i.putExtra("nameuser",username);
            i.putExtra("password",password);
            i.putExtra("firstName",firstName);
            i.putExtra("lastName",lastName);
            i.putExtra("department",dept);
            i.putExtra("position",pos);
            i.putExtra("story",story);
            i.putExtra("location",location);
            i.putExtra("image",image);
            Log.d("myname", "onOptionsItemSelected: "+image);
            i.putExtra("pointsToaward","1000");
            startActivity(i);

        }
        if (id == R.id.leader) {
            Intent i = new Intent(getApplicationContext(), LeaderBoard.class);
            i.putExtra("nameuser",username);
            i.putExtra("password",password);
            i.putExtra("firstName",firstName);
            i.putExtra("lastName",lastName);
            i.putExtra("department",dept);
            i.putExtra("position",pos);
            i.putExtra("story",story);
            i.putExtra("location",location);
            i.putExtra("image",image);
            Log.d("myname", "onOptionsItemSelected: "+image);
            i.putExtra("pointsToaward","1000");
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }
    public void set_adapt(JSONArray js)
    {
        try{
            for(int i=0; i<js.length(); i++)
            {
                JSONObject jsonObject = js.getJSONObject(i);
                hist_val re = new hist_val();
                re.setDate(String.valueOf(jsonObject.getString("date")));
                re.setName(jsonObject.getString("name"));
                re.setPoints(jsonObject.getString("value"));
                re.setComments(jsonObject.getString("comments"));
                rewardlist.add(re);
            }
//            history.setText("Reward History " + "("+js1.length()+")");
            madapter.notifyDataSetChanged();

        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }


}



