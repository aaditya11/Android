package com.example.inspiration_awards;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class LeaderBoardAdap extends RecyclerView.Adapter<LeaderBoardAdap.ViewHolder> {
    private LeaderBoard context;
    private List<LeaderBoardValue> list;
    private LeaderBoard getAllProfile;
    private static final String TAG = "StockAdapter";
    private String username;

    public LeaderBoardAdap(LeaderBoard mainActivity, List<LeaderBoardValue> list) {
        this.context = mainActivity;
        this.list = list;
    }


    public void Refreshadapter(List<LeaderBoardValue> list)
    {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_lb_data, viewGroup, false);
        view.setOnClickListener(context);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        LeaderBoardValue st = list.get(position);
        byte [] encodeByte= Base64.decode(st.getImage(),Base64.DEFAULT);
        Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
        viewHolder.image.setImageBitmap(bitmap);
        viewHolder.name.setText(String.valueOf(st.getName()));
        viewHolder.points.setText(String.valueOf(st.getPoints()));
        Log.d(TAG,"points-----------"+st.getPoints());
        username=context.nme;
        viewHolder.position.setText(String.valueOf(st.getPositions()));
        //Log.d(TAG,"username equals-------------"+st.getUsername());
        Log.d("hhhh",st.getName()+"username equals-------------"+username);

        if(String.valueOf(st.getName()).equals(username))
        {
            Log.d("hhh2",username+".....  username equals-------------"+st.getName());
            viewHolder.name.setTextColor(Color.GREEN);
            viewHolder.points.setTextColor(Color.GREEN);
            viewHolder.position.setTextColor(Color.GREEN);
        }

//        if(String.valueOf(st.getName()).equals(username))
//        {
//            Log.d("hhhh",st.getUsername()+"username equals-------------"+username);
//            viewHolder.name.setTextColor(Color.GREEN);
//            viewHolder.points.setTextColor(Color.GREEN);
//            viewHolder.position.setTextColor(Color.GREEN);
//        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView image;
        public TextView name;
        public TextView points;
        public TextView position;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.photo);
            name = itemView.findViewById(R.id.lName);
            points = itemView.findViewById(R.id.points);
            position = itemView.findViewById(R.id.dept);
        }
    }
}
