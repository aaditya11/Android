package com.example.inspiration_awards;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class LeaderBoard extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "LeaderBoard";
    private RecyclerView recyclerView;
    private static String[] s;
    private static String stored_result;
    private static LeaderBoardAdap adapter;
    private String sId, username, password;
    private final static List<LeaderBoardValue> leaderlist = new ArrayList<>();
    String f_n,l_n,nme;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Inspiration Leader Board");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setLogo(R.drawable.arrow_with_logo);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.arrow_with_logo);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setContentView(R.layout.activity_leader_board);
        sId =  "A20424216"   ;
        username = getIntent().getStringExtra("nameuser") ;
        Log.d("Amun", "onCreate: "+username);
        password = getIntent().getStringExtra("password");
        f_n=getIntent().getStringExtra("firstName");
        Log.d("hhhh", "onCreate: "+f_n);
        l_n=getIntent().getStringExtra("lastName");
        nme=l_n+", "+f_n;
        try{
            if(nme==null){
            String nme1=getIntent().getStringExtra("nme");
            nme=nme;}
        }catch(Exception e){

        }

        recyclerView = findViewById(R.id.recycler);
        adapter = new LeaderBoardAdap(LeaderBoard.this, leaderlist);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        new LeaderBoardAsync().execute(sId, username, password);
    }


    public void result(String s) {
        Log.d(TAG, "result-----------------" + s);
        if (s == "FAILED") {
            Toast.makeText(LeaderBoard.this, "Error Occurred while loading page!!", Toast.LENGTH_SHORT).show();
        } else {
            try {
                stored_result = s;
                Log.d(TAG, "result stored 12222---------------" + stored_result);
                JSONArray jsonArray = new JSONArray(s);
                ArrayList<LeaderBoardValue> ls = new ArrayList<>();
                Log.d(TAG, "length of json-----------" + jsonArray.length());
                for (int i = 0; i < jsonArray.length(); i++) {
                    Log.d(TAG, "length of leaderlist-----------" + leaderlist.size());
                    LeaderBoardValue l = new LeaderBoardValue();
                    JSONObject j = jsonArray.getJSONObject(i);
                    l.setName(j.getString("lastName") + ", " + j.getString("firstName"));
                    l.setPositions(j.getString("position") + ", " + j.getString("department"));
                    l.setImage(j.getString("imageBytes"));
                    l.setUsername(j.getString("username"));
                    int pnts=0;
                    if(j.has("rewards") && !j.isNull("rewards")) {
                        JSONArray rewardsArray = j.getJSONArray("rewards");
                        for (int y = 0; y < rewardsArray.length(); y++) {
                            JSONObject reward = rewardsArray.getJSONObject(y);
                            int pnts1 = (int) reward.getInt("value");
                            Log.d("pnt", "setData: "+pnts1);
                            pnts = pnts+pnts1;}}
                    l.setPoints(Integer.toString(pnts));
                    ls.add(l);
                }
                //leaderlist.addAll(ls);
                callsetadapter(ls);
                //adapter.notifyDataSetChanged();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void callsetadapter(ArrayList<LeaderBoardValue> ls) {
        leaderlist.clear();
        //adapter.Refreshadapter(leaderlist);
        leaderlist.addAll(ls);
        adapter.Refreshadapter(leaderlist);
    }

    public void onClick(View view) {
        JSONObject store = new JSONObject();
        int pos = recyclerView.getChildLayoutPosition(view);
        LeaderBoardValue s = leaderlist.get(pos);
        Log.d(TAG, "psoition-----------" + s.getName());
        try {
            Log.d(TAG, "see mee---------------" + stored_result);
            JSONArray j = new JSONArray(stored_result);
            for (int i = 0; i < j.length(); i++) {
                JSONObject obj = j.getJSONObject(i);
                if (obj.getString("username").equals(s.getUsername())) {
                    store = obj;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        String[] s1 = new String[4];
        s1[0] = sId;
        Log.d("Amun", "onClick: "+s1[0]);
        s1[1] = username;
        s1[2] = password;
        s1[3] = store.toString();
        Log.d("Amun", "onClick: "+s1[3]);
        if(s.getName().equals(nme)){
            Toast.makeText(this,"Reward to Self not allowed",Toast.LENGTH_SHORT).show();
        }
        else{
        Intent i = new Intent(LeaderBoard.this, AwardActivity.class);
        i.putExtra("obj", s1);
        i.putExtra("nme",nme);
        startActivity(i);}
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Log.d(TAG, "callback---------------------");
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


}