package com.example.inspiration_awards;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class AwardActivity extends AppCompatActivity {
    String sid1,usr1,pss1,obj2,f_n,l_n,pos,dept,image,u_n,story,nme;
    int awrd;
    String[] obj;
    TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7;
    ImageView im_g;
    String name;
    EditText ed1,ed2,ed3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_award);
       obj= getIntent().getStringArrayExtra("obj");
        sid1=obj[0];
        Log.d("ho rha", "onCreate: "+sid1);
        usr1=obj[1];
        pss1=obj[2];
        obj2=obj[3];
        nme=getIntent().getStringExtra("nme");
        try {
            JSONObject jsonObject =new JSONObject(obj2);
            u_n=jsonObject.getString("username");
            f_n=jsonObject.getString("firstName");
            l_n=jsonObject.getString("lastName");
            pos=jsonObject.getString("position");
            dept=jsonObject.getString("department");
            image=jsonObject.getString("imageBytes");
            awrd=jsonObject.getInt("pointsToAward");
            story=jsonObject.getString("story");
            name=f_n+" "+l_n;




        }catch (Exception e){
            Toast.makeText(this,""+e,Toast.LENGTH_SHORT).show();
        }


       tv1=findViewById(R.id.textView5);
        tv2=findViewById(R.id.textView6);
        tv3=findViewById(R.id.textView8);
        im_g=findViewById(R.id.imageView5);
        tv4=findViewById(R.id.tv1);
        setTitle(f_n+" "+l_n);
        tv5=findViewById(R.id.editText6);
        ed1=findViewById(R.id.editText8);
        tv6=findViewById(R.id.textView14);
        ed2=findViewById(R.id.editText7);
        ed3=findViewById(R.id.editText8);


        tv1.setText(l_n+","+f_n+"  ("+u_n+")");
        tv2.setText("Department:\n "+dept);
        tv3.setText("Position:\n "+pos);
        tv4.setText("Points Awarded:  "+awrd);
        tv5.setText("Your Story: "+"\n "+story);



        if(image!=null)
        {

            byte [] imageBytes = Base64.decode(image, Base64.DEFAULT);
            Log.d("nunn3", "doConvert: Image byte array length: " + image.length());
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            Log.d("nunn3", "" + bitmap);

            im_g.setImageBitmap(bitmap);
        }
        addTextListener();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.award_menu, menu);
        return true;
    }

    private void addTextListener() {
        ed1.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // Nothing to do here
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
                // Nothing to do here
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                int len = s.toString().length();
                String countText = "(" + len + " of " + 80 + ")";
                tv6.setText(countText);
            }
        });
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.save4) {
            String comments=ed3.getText().toString();
            String value=ed2.getText().toString();
            if(!value.isEmpty())
            {
                new Award_Asynch(this).execute(usr1,pss1,name,u_n,comments,value);
                return true;
            }
            else{
                Toast.makeText(getApplicationContext(),"Enter a Value!!",Toast.LENGTH_LONG).show();
            }}
        return super.onOptionsItemSelected(item);
}
   public void done()
   {
       Intent intent=new Intent(this,LeaderBoard.class);
       Toast.makeText(this,"Reward Added Successfully",Toast.LENGTH_SHORT).show();
       intent.putExtra("username",usr1);
       intent.putExtra("password",pss1);
       intent.putExtra("firstname",f_n);
       intent.putExtra("lastname",l_n);
       intent.putExtra("nme",nme);
       startActivity(intent);
   }
}
